# Calculator

Build a simple calculator that performs a sum of two numbers.

You can focus on a simple UI for now.

![Calculator](calculator.png)

There should be two inputs and a button.

When the button is clicked the sum of both numbers should be displayed in the page.

We recommend that you use [JQuery](https://jquery.com/)

We encourage you to google as much as you want on how to perform this task.

Good luck :)
