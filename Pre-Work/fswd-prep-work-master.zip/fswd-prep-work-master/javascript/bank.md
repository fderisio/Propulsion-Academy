# Bank

Let's create a Class `Bank` that will be able to manage the savings of our customers.

The `Bank` should allow us to:
- Add customers
- A customer should be able to deposit an amount.
- A customer should be able to withdraw an amount.
- A customer should be able see his/her account.

### Bank Class

Create the `Bank` class.

Create the `Bank` class and initialize on instance.

```javascript
var bank = new Bank();
```

### Add Customers

The only thing that the `Bank` will have are customers.

In order to store the customers we can use an object `{}`.

In the constructor of the `Bank`, initialize an instance variable to an empty object.

```javascript
// ...
this.customers = {};
// ...
```

Let's consider a customer to be just a string, when we add a customer, we will add a key to our `this.customers` object.

The value of the key will be the account of that user. We can set it to 0 at the beginning.

*There are 2 ways to access properties in an object. Dot notation and bracket notation. Check [this](https://developer.mozilla.org/ca/docs/Web/JavaScript/Reference/Operators/Property_Accessors) article for more info*

In order to add a customer, add a method to our class called `addCustomer`.

```javascript
Bank.prototype.addCustomer = function(customer) {
  // ...
}
```

By the end of this step you should be able to add new customers.

```javascript
var bank = new Bank();
bank.addCustomer('Sheldor');
```

### Print Account

Add another method called `printAccount`.

This method should expect a customer and print the account of that customer.

It could print something like this: `Sheldor account is 0`.

```javascript
var bank = new Bank();
bank.addCustomer('Sheldor');
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 0'
```

### Deposit Amounts

Next step is to allow our customers to deposit some amount into our bank.

Create a method called `deposit` that expects a customer and an amount as parameters.

This method should increment the account of the customer by the amount passed.

```javascript
var bank = new Bank();
bank.addCustomer('Sheldor');
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 0'
bank.deposit('Sheldor', 10); // new method
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 10'
```

### Withdrawings

Let's allow our users to withdraw from their accounts.

Create a method `withdraw` that expects a customer and an amount as parameters.

It should subtract that amount from the customers account.

```javascript
var bank = new Bank();
bank.addCustomer('Sheldor');
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 0'
bank.deposit('Sheldor', 10); // new method
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 10'
bank.withdraw('Sheldor', 2);
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 8'
```

### Final check

Make sure you can add more customers and every account is managed differently.

At this point you should be able to run this code and get reasonable outputs:

```javascript
var bank = new Bank();
bank.addCustomer('Sheldor');
bank.printAccount('Sheldor');
bank.deposit('Sheldor', 10);
bank.printAccount('Sheldor');
bank.addCustomer('Raj');
bank.printAccount('Raj');
bank.deposit('Raj', 10000);
bank.printAccount('Raj');
bank.withdraw('Raj', 100);
bank.printAccount('Sheldor'); // this should print 'Sheldor account is 10'
bank.printAccount('Raj'); // this should print 'Raj account is 9900'
```

**Please email your solution to <learn@propulsionacademy.com> once you have finished the exercise.**

### Bonus features

- What happens when someone tries to withdraw and there is not enough amount? Do not allow withdrawing and print some message.
- Add a method that prints all the customers and their accounts
